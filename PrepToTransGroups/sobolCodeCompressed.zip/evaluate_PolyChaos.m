
baseDomain=domain(1,:);
baseDomain(end-5:end-4)=domain(2,end-5:end-4);
baseDomain(end-1:end)=domain(2,end-1:end);

evalDomain=baseDomain;
%evalDomain(end-5)=.02;
%evalDomain(end-4)=.02;
%evalDomain(end-3)=.531;
%evalDomain(end-2)=.473;
%evalDomain(end-1)=.2502;
%evalDomain(end)=.246;
%evalDomain(1)=1;
%evalDomain(2)=1;


idx_dx=15;
relevantInterval=linspace(domain(1,idx_dx),domain(2,idx_dx),100);
%intervalHisp=linspace(move5to4_Hisp(1),move5to4_Hisp(2),100)';
%intervalHisp=linspace(0,1,100);


polyChaosEval=0;
XX=Sr.knots;
output_Of_Interest=[];
output_Of_Interest_Deriv=[];
output_Of_Interest_DerivAnalytic=[];
      
[modal_coeffs1,K1] = convert_to_modal(S,Sr,values_g1(12,:),domain,'legendre');    
[modal_coeffs2,K2] = convert_to_modal(S,Sr,values_g2(12,:),domain,'legendre');    
[modal_coeffs3,K3] = convert_to_modal(S,Sr,values_g3(12,:),domain,'legendre');    
[modal_coeffs4,K4] = convert_to_modal(S,Sr,values_g4(12,:),domain,'legendre');    
[modal_coeffs5,K5] = convert_to_modal(S,Sr,values_g6(12,:),domain,'legendre');    

[deriv_modal_coeffs1,deriv_K1]=compute_DerivativePolyChaos(modal_coeffs1,K1,idx_dx);
[deriv_modal_coeffs2,deriv_K2]=compute_DerivativePolyChaos(modal_coeffs2,K2,idx_dx);
[deriv_modal_coeffs3,deriv_K3]=compute_DerivativePolyChaos(modal_coeffs3,K3,idx_dx);
[deriv_modal_coeffs4,deriv_K4]=compute_DerivativePolyChaos(modal_coeffs4,K4,idx_dx);
[deriv_modal_coeffs5,deriv_K5]=compute_DerivativePolyChaos(modal_coeffs5,K5,idx_dx);



for j=1:length(relevantInterval)

     
    evalDomain(3)=relevantInterval(j);

    %evalDomain(1)=prepLvls(j);     
    %evalDomain(2)=prepLvls(j);        
     
     polyChaosEval=zeros(1,5);
     polyChaosEvalDeriv=zeros(1,5);
     
     for i=1:length(modal_coeffs1)          
        polyChaosEval(1)=polyChaosEval(1)+modal_coeffs1(i)*lege_eval_multidim(evalDomain',K1(i,:),domain(1,:),domain(2,:));
        polyChaosEval(2)=polyChaosEval(2)+modal_coeffs2(i)*lege_eval_multidim(evalDomain',K2(i,:),domain(1,:),domain(2,:));
        polyChaosEval(3)=polyChaosEval(3)+modal_coeffs3(i)*lege_eval_multidim(evalDomain',K3(i,:),domain(1,:),domain(2,:));
        polyChaosEval(4)=polyChaosEval(4)+modal_coeffs4(i)*lege_eval_multidim(evalDomain',K4(i,:),domain(1,:),domain(2,:));
        polyChaosEval(5)=polyChaosEval(5)+modal_coeffs5(i)*lege_eval_multidim(evalDomain',K5(i,:),domain(1,:),domain(2,:));

       polyChaosEvalDeriv(1)=polyChaosEvalDeriv(1)+deriv_modal_coeffs1(i)*lege_eval_multidim_partialDer(evalDomain',deriv_K1(i,:),domain(1,:),domain(2,:),idx_dx);
       polyChaosEvalDeriv(2)=polyChaosEvalDeriv(2)+deriv_modal_coeffs2(i)*lege_eval_multidim_partialDer(evalDomain',deriv_K2(i,:),domain(1,:),domain(2,:),idx_dx);
       polyChaosEvalDeriv(3)=polyChaosEvalDeriv(3)+deriv_modal_coeffs3(i)*lege_eval_multidim_partialDer(evalDomain',deriv_K3(i,:),domain(1,:),domain(2,:),idx_dx);
       polyChaosEvalDeriv(4)=polyChaosEvalDeriv(4)+deriv_modal_coeffs4(i)*lege_eval_multidim_partialDer(evalDomain',deriv_K4(i,:),domain(1,:),domain(2,:),idx_dx);
       polyChaosEvalDeriv(5)=polyChaosEvalDeriv(5)+deriv_modal_coeffs5(i)*lege_eval_multidim_partialDer(evalDomain',deriv_K5(i,:),domain(1,:),domain(2,:),idx_dx);


     end

    output_Of_Interest=[output_Of_Interest;polyChaosEval];
    output_Of_Interest_DerivAnalytic=[output_Of_Interest_DerivAnalytic;polyChaosEvalDeriv];

end

dx=relevantInterval(2)-relevantInterval(1);

output_Of_Interest_Deriv=(output_Of_Interest(3:end,:)-output_Of_Interest(1:end-2,:))/(2*dx);
output_Of_Interest_Deriv2=(output_Of_Interest(3:end,:)-2*output_Of_Interest(2:end-1,:) + output_Of_Interest(1:end-2,:))/((relevantInterval(2)-relevantInterval(1))^2);

